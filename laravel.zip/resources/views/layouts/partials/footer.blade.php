<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <a href="http://iscah.cl" >Iscah</a> 2022</span>
        </div>
    </div>
</footer>