@extends('layouts.tag')

@section('titulo_card', 'Solicita tu Tag Online!')

@section('contenido')

<div class="form-group ">
    <div class="form-group text-center">
        <h5><p class="small text-primary">Seleccione el Tipo de Solicitud a Realizar :</p></h5>
    </div>  

    <a href="{{ route('natural') }}" class="btn btn-primary btn-user btn-block">
        <i class="fa-solid fa-person"></i>   Persona Natural
    </a>
    <a href="{{ route('empresa') }}" class="btn btn-facebook btn-user btn-block">
        <i class="fa-solid fa-industry"></i>   Empresa
    </a>
</div>


@endsection