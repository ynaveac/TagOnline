@extends('layouts.admin')

@section('titulo', 'Panel Solicitudes Tag')

@section('contenido')
    
    <div class="card">
        <div class="card-body">
            <table id="dt-products" class="table table-striped table-bordered dts">
                <thead>
                    <tr>
                        <th class="text-center">Fecha Solicitud</th>
                        <th class="text-center">Local</th>
                        <th class="text-center">Vendedor</th>
                        <th class="text-center">Patente</th>
                        <th class="text-center">Tipo</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                    @foreach ($solicitudes as $solicitud)
                        <tr class="text-center">
                            <td>{{ $solicitud->fecha_proceso }}</td>
                            <td>{{ $solicitud->local }}</td>
                            <td>{{ $solicitud->vendedor }}</td>
                            <td>{{ $solicitud->patente }}</td>
                            <td>{{ $solicitud->tipo }}</td>
                            <td>{{ $solicitud->estado }}</td>
                            <td>
                                <a href="" class="edit-form-data" data-toggle="modal" data-target="#editMdl-{{ $solicitud->id }}">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="" class="delete-form_data" data-toggle="modal" data-target="#deleteMdl">
                                    <i class="far fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        @include('request_tag.modals.update')
                        @include('request_tag.modals.delete')
                    @endforeach
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

@endsection

@push('styles')
    <link rel="stylesheet" href="{{ asset('libs/datatables/dataTables.bootstrap4.min.css') }}">
@endpush

@push('scripts')
    <script src="{{ asset('libs/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('libs/datatables/dataTables.bootstrap4.min.js') }}"></script>
@endpush