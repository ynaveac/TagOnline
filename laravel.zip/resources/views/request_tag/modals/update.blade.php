<!-- Modal -->
<form action="" method="POST" enctype="multipart/form-data">

    <div class="modal fade" id="editMdl-{{ $solicitud->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edición de Solicitud</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            
            <div class="modal-body">
                <div class="form-group row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <label for="rut" class="form-control form-control-user">Rut : {{ $solicitud->rut }}</label>
                    </div>
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <label for="rut" class="form-control form-control-user">Estado : {{ $solicitud->estado }}</label>
                    </div>
                </div>
                <select id="select_estado" name="select_estado" class="form-control form-select" aria-label="Default select example">
                    <option selected>Seleccione un Estado a Actualizar</option>
                    <option value="Pendiente">Pendiente</option>
                    <option value="Aprobado">Aprobado</option>
                    <option value="Rechazado">Rechazado</option>
                  </select>
            </div>

            <div class="col-sm-6 mb-3 mb-sm-0">
                <img src="{{ $solicitud->carnetfrontal }}" alt="">
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <button type="button" class="btn btn-primary">Guardar Cambios</button>
            </div>
        </div>
        </div>
    </div>
    
</form>