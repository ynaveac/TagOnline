<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Arr;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use Twilio\Rest\Client;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
//use Validator;

class MensajeriaController extends Controller
{

    public function mensajes(Request $request){

    /*
       // Your Account SID and Auth Token from twilio.com/console
       $sid    = env( 'TWILIO_SID' );
       $token  = env( 'TWILIO_TOKEN' );
       $client = new Client( $sid, $token );


            $number = '+56958496962';

            $message = 'Prueba de Envio';
            $count = 0;

               $count++;

               $client->messages->create(
                   $number,
                   [
                       'from' => env( 'TWILIO_FROM' ),
                       'body' => $message,
                   ]
               );

           echo 'Mensaje Enviado!';
                     
    }
    */
 
    QrCode::generate('TAGS!', '../public/qrcodes/qrcode.svg');
    
    $mensaje = "test codigo QR";
    
    $mediaUrl = 'https://www.ocu.org/-/media/ta/images/qr-code.png?rev=2e1cc496-40d9-4e21-a7fb-9e2c76d6a288&hash=AF7C881FCFD0CBDA00B860726B5E340B&mw=960';

    $celular = '+56958496962';

    $sid    = env( 'TWILIO_SID' );
    $token  = env( 'TWILIO_TOKEN' );
    $twilio = new Client($sid, $token); 
     
    $message = $twilio->messages 
                      ->create("whatsapp:".$celular, // to 
                               array( 
                                    "mediaUrl" => [$mediaUrl],
                                    "from" => "whatsapp:+14155238886",       
                                    "body" => $mensaje
                               ) 
                      ); 
     
    print($message->sid);
    }

}
