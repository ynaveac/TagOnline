<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreFirmasRequest;
use App\Http\Requests\UpdateFirmasRequest;
use App\Models\Firmas;
use App\Http\Controllers\Arr;

class FirmasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view ('tag.firma');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreFirmasRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreFirmasRequest $request)
    {
        
        $datos = $request;
        //dd($request->firmaok);
        $tarea = Firmas::create($datos->all());
        return redirect()->action([TransbankController::class, 'iniciar_compra'], ['id' => $datos->id_RequestTag]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Firmas  $firmas
     * @return \Illuminate\Http\Response
     */
    public function show(Firmas $firmas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Firmas  $firmas
     * @return \Illuminate\Http\Response
     */
    public function edit(Firmas $firmas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateFirmasRequest  $request
     * @param  \App\Models\Firmas  $firmas
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateFirmasRequest $request, Firmas $firmas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Firmas  $firmas
     * @return \Illuminate\Http\Response
     */
    public function destroy(Firmas $firmas)
    {
        //
    }
}
