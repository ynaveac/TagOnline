<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\RequestTag;
use App\Http\Controllers\Arr;
use App\Http\Requests\TagRequest;
use Illuminate\Support\Facades\DB;

class RequestTagController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        //$solicitudes = RequestTag::get();
        $solicitudes = DB::select('select 
        rt.id ,
        rt.fecha_proceso ,
        rt.local ,
        rt.vendedor ,
        rt.tipo ,
        rt.rut ,
        rt.rut_representante ,
        rt.nombre_representante ,
        rt.nombre ,
        rt.direccion ,
        rt.telefono ,
        rt.email ,
        rt.patente ,
        rt.marca ,
        rt.modelo ,
        rt.observaciones ,
        rt.estado ,
        d.id_RequestTag ,
        d.carnetfrontal ,
        d.carnetfrontalempresa ,
        d.primerainscripcion ,
        d.compranotarial ,
        d.padron ,
        d.cav ,
        f.firmaok ,
        f.firma ,
        t.estado as estado_compra ,
        t.transactionDate ,
        t.total 
        from 
        RequestTag rt 
        left join documents d on rt.id = d.id_RequestTag
        left join firmas f on rt.id = f.id_RequestTag 
        left join transbanks t on rt.id = t.sessionId');

        return view ('request_tag.index', compact('solicitudes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TagRequest $request)
    {
        $datos = $request;
        $datos = array_add($datos, 'local', 500);
        $datos = array_add($datos, 'vendedor', 500);
        $datos = array_add($datos, 'estado', 'Pendiente');
        
        //dd($datos);

        $existe = RequestTag::where("rut",'=',"$datos->rut")->where("patente",'=',"$datos->patente")->first();

        if(!isset($existe)){
            $tarea = RequestTag::create($datos->all());
            //return view('tag.document', ['id' => $tarea->id]); 
            //Route::redirect('/document', ['id' => $tarea->id]);
            return redirect()->action([DocumentsController::class, 'index'], ['id' => $tarea->id, 'tipo' => $tarea->tipo]);
        }else{
            //return view('tag.document', ['id' => $existe->id]); 
            //Route::redirect('/document');
            //return redirect('/document');
            //return redirect()->route('document');
            return redirect()->action([DocumentsController::class, 'index'], ['id' => $existe->id, 'tipo' => $existe->tipo]);
        }

        //alert()->success('Tag Online!', 'Falta Poco, continuemos...');
        //return redirect()->route('home');  
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
