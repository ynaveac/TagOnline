<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\RequestTagController;
use App\Http\Controllers\DocumentsController;
use App\Http\Controllers\FirmasController;
use App\Http\Controllers\MensajeriaController;
use App\Http\Controllers\ComercioController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/suscripcion', function () { return view('tag.index'); });
Route::get('/natural', function () { return view('tag.natural'); })->name('natural');
Route::get('/empresa', function () { return view('tag.empresa'); })->name('empresa');
Route::get('/document', function () { return view('tag.document'); })->name('document');
Route::get('/mensaje', [MensajeriaController::class, 'mensajes'])->name('mensaje');



Route::get('/dashboard', [HomeController::class, 'index'])->name('home');

Route::resource('/request_tag', RequestTagController::class);
Route::resource('/document', DocumentsController::class);
Route::resource('/firma', FirmasController::class);


Route::resource('/comercio', ComercioController::class);