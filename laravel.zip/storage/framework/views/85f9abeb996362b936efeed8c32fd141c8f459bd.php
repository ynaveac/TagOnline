<?php $__env->startSection('titulo_card', 'Validar Para Entrega de Tag!'); ?>

<?php $__env->startSection('contenido'); ?>

<form class="user" action="#" method="post" >
    <?php echo csrf_field(); ?>

    <input type="hidden" name="fecha_proceso" id="fecha_proceso" value="<?php echo e(date('Y-m-d\TH:i', strtotime(now()))); ?>" />
    <div class="form-group ">
        <div class="form-group text-center">
            <h5><p class="small text-primary">Proceso de Entrega de Tag</p></h5>
        </div>  

        <div class="form-group row">

            <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" name="codigoqr" id="codigoqr" placeholder="Codigo QR" maxlength="11" class="form-control form-control-user" value=""/>
            </div>

            <div class="col-sm-6 mb-3 mb-sm-0">
                <label for="rut" id="rut" name="rut" class="form-control form-control-user"></label>
            </div>

        </div>

        <div class="form-group row">

            <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" name="codigoqr" id="codigoqr" placeholder="codigo local" maxlength="11" class="form-control form-control-user" value=""/>
            </div>

            <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" name="codigoqr" id="codigoqr" placeholder="codigo vendedor" maxlength="11" class="form-control form-control-user" value=""/>
            </div>

        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE-Twilio-MSM/resources/views/comercio/index.blade.php ENDPATH**/ ?>