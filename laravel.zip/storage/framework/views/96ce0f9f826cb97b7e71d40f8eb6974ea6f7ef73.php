<?php $__env->startSection('titulo_card', 'Cargando Documentos!'); ?>

<?php $__env->startSection('imagen', "background-image: url('https://www.portafolio.co/files/article_multimedia/uploads/2017/11/22/5a15bb0831832.jpeg')"); ?>

<?php $__env->startSection('contenido'); ?>
    
    <form class="user" action="<?php echo e(route('document.store')); ?>" method="post" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <input type="hidden" name="id_RequestTag" id="id_RequestTag" value="<?php echo e($_REQUEST['id']); ?>" />
        <div class="form-group text-center">
            <h5><p class="small ">Subir Archivos</p></h5>
        </div>
        <div class="form-group row">
            <div class="input-group" id="carnetfrontal-form">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="carnetfrontal">Carnet</span>
                </div>
                <div class="custom-file">
                  <input type="file" class="custom-file-input <?php echo e($errors->has('carnetfrontal') ? 'is-invalid' : ''); ?>" id="carnetfrontal" name="carnetfrontal">
                  <label class="custom-file-label" for="carnetfrontal">Imagen Frontal del Carnet</label>
                </div>
            </div>
        </div>
        <div class="form-group row">
            <div class="input-group" id="carnetreverso-form">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="carnetreverso">Carnet</span>
                </div>
                <div class="custom-file">
                  <input type="file" class="custom-file-input <?php echo e($errors->has('carnetreverso') ? 'is-invalid' : ''); ?>" id="carnetreverso" name="carnetreverso">
                  <label class="custom-file-label" for="carnetreverso">Imagen Reverso del Carnet</label>
                </div>
            </div>            
        </div>

            <div class="form-group text-center">
                <h5><p class="small text-primary">Documentos del Vehiculo:</p></h5>
            </div>  
            <div class="form-group row">
                <div class="input-group" id="primerainscripcion-form">
                    <div class="input-group-prepend">
                    <span class="input-group-text" id="primerainscripcion">Vehiculo Nuevo</span>
                    </div>
                    <div class="custom-file">
                    <input type="file" class="custom-file-input <?php echo e($errors->has('primerainscripcion') ? 'is-invalid' : ''); ?>" id="primerainscripcion" name="primerainscripcion">
                    <label class="custom-file-label" for="primerainscripcion">Primera Inscripción</label>
                    </div>
                </div>            
            </div>      

        <div class="form-group text-center">
            <h6><p class="small text-danger">Si es un Vehiculo Usado, Suba uno de los siguientes Documentos :</p></h6>
        </div>  
        <div class="form-group row">
            <div class="input-group" id="compranotarial-form">
                <div class="input-group-prepend">
                <span class="input-group-text" id="compranotarial">Vehiculo Usado</span>
                </div>
                <div class="custom-file">
                <input type="file" class="custom-file-input <?php echo e($errors->has('compranotarial') ? 'is-invalid' : ''); ?>" id="compranotarial" name="compranotarial">
                <label class="custom-file-label" for="compranotarial">Compra Venta Notarial</label>
                </div>
            </div>            
        </div>   
        <div class="form-group row">
            <div class="input-group" id="padron-form">
                <div class="input-group-prepend">
                <span class="input-group-text" id="padron">Vehiculo Usado</span>
                </div>
                <div class="custom-file">
                <input type="file" class="custom-file-input <?php echo e($errors->has('padron') ? 'is-invalid' : ''); ?>" id="padron" name="padron">
                <label class="custom-file-label" for="padron">Padron</label>
                </div>
            </div>            
        </div>  
        <div class="form-group row">
            <div class="input-group" id="cav-form">
                <div class="input-group-prepend">
                <span class="input-group-text" id="cav">Vehiculo Usado</span>
                </div>
                <div class="custom-file">
                <input type="file" class="custom-file-input <?php echo e($errors->has('cav') ? 'is-invalid' : ''); ?>" id="cav" name="cav">
                <label class="custom-file-label" for="cav">CAV</label>
                </div>
            </div>            
        </div>  

        <div class="form-group">
            <input type="submit" value="Subir Archivos" class="btn btn-primary btn-user btn-block" />
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE/resources/views/tag/document.blade.php ENDPATH**/ ?>