<?php $__env->startSection('titulo_card', 'Rechazado!!'); ?>

<?php $__env->startSection('contenido'); ?>

<div class="card text-center">
    <div class="card-header">
      Lamentablemente tu Pago ha sido Rechazado!!
    </div>
    <div class="card-body">
      <!--  
      <h5 class="card-title">Special title treatment</h5>
      <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
      -->
        <div>
            <i class="fa-solid fa-circle-xmark text-danger fa-10x "></i>
        </div>

    </div>
    <div class="card-footer text-muted">
        <a href="#" class="btn btn-primary">Finalizar</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE/resources/views/tag/rechazado.blade.php ENDPATH**/ ?>