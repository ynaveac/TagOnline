<?php $__env->startSection('titulo', 'Panel Solicitudes Tag'); ?>

<?php $__env->startSection('contenido'); ?>
    
    <div class="card">
        <div class="card-body">
            <table id="dt-products" class="table table-striped table-bordered dts">
                <thead>
                    <tr>
                        <th class="text-center">Fecha Solicitud</th>
                        <th class="text-center">Local</th>
                        <th class="text-center">Vendedor</th>
                        <th class="text-center">Patente</th>
                        <th class="text-center">Tipo</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                    <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($solicitud->fecha_proceso); ?></td>
                            <td><?php echo e($solicitud->local); ?></td>
                            <td><?php echo e($solicitud->vendedor); ?></td>
                            <td><?php echo e($solicitud->patente); ?></td>
                            <td><?php echo e($solicitud->tipo); ?></td>
                            <td><?php echo e($solicitud->estado); ?></td>
                            <td>
                                <a href="" class="edit-form-data" data-toggle="modal" data-target="#editMdl-<?php echo e($solicitud->id); ?>">
                                    <i class="far fa-edit"></i>
                                </a>
                                <a href="" class="delete-form_data" data-toggle="modal" data-target="#deleteMdl">
                                    <i class="far fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php echo $__env->make('request_tag.modals.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('request_tag.modals.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('libs/datatables/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('libs/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE-Twilio-MSM/resources/views/request_tag/index.blade.php ENDPATH**/ ?>