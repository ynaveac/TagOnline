<?php $__env->startSection('titulo_card', 'Ultimo paso para Obtener tu Tag'); ?>

<?php $__env->startSection('imagen', "background-image: url('https://www.autopista.es/uploads/s1/56/94/52/0/article-10-consejos-para-compartir-coche-y-ahorrar-101655-5418000694cd1.jpeg')"); ?>

<?php $__env->startSection('contenido'); ?>

<form class="user" action="<?php echo e(route('firma.store')); ?>" method="post" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>

    <input type="hidden" name="id_RequestTag" id="id_RequestTag" value="<?php echo e($_REQUEST['id']); ?>" />
    <div class="form-group text-center">
        <span><h6>Realizar Firma.</h6></span>
    </div>  
    <div class="form-group text-center">
        <canvas id="canvas" class="col-sm-6 mb-3 mb-sm-0"></canvas>
        <?php if($errors->first('firma')): ?>
            <span><h6 class="text-danger"><?php echo e($errors->first('firma')); ?></h6></span>
        <?php endif; ?>
        <?php if($errors->first('firmaok')): ?>
            <span><h6 class="text-danger"><?php echo e($errors->first('firmaok')); ?></h6></span>
        <?php endif; ?>
    </div>
    <div class="form-group row">
        <div class="col-sm-6 mb-3 mb-sm-0">    
            <a id="limpiar" href="#" class="btn btn-primary btn-user btn-block">
                Borrar Firma
            </a>
        </div>
        <div class="col-sm-6 mb-3 mb-sm-0"> 
            <span class="input-group-text">
                <input type="checkbox" id="firmaok" name="firmaok" value="1">
                <label class="form-check-label" for="firmaok" onclick="btnSave()"> - Fidedigna a C.I. </label>
            </span>
        </div>   
    </div> 
    <div class="form-group row">      
        <div class="col-md-12">
            <img id = "imgCapture" name="imgCapture" alt = "" style = "display:none;border:1px solid #ccc" />
            <input type="hidden" id="firma" name="firma">
        </div>
    </div>
    <div class="form-group">
        <input type="submit" value="Realizar Pago" class="btn btn-primary btn-user btn-block" />
    </div>
</form>
<script src="<?php echo e(asset('js/firma.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE/resources/views/tag/firma.blade.php ENDPATH**/ ?>