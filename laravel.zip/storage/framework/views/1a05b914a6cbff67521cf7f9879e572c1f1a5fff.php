<?php $__env->startSection('titulo_card', 'Solicita tu Tag Online!'); ?>

<?php $__env->startSection('contenido'); ?>

<div class="form-group ">
    <div class="form-group text-center">
        <h5><p class="small text-primary">Seleccione el Tipo de Solicitud a Realizar :</p></h5>
    </div>  

    <a href="<?php echo e(route('natural')); ?>" class="btn btn-primary btn-user btn-block">
        <i class="fa-solid fa-person"></i>   Persona Natural
    </a>
    <a href="<?php echo e(route('empresa')); ?>" class="btn btn-facebook btn-user btn-block">
        <i class="fa-solid fa-industry"></i>   Empresa
    </a>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE-Twilio-MSM/resources/views/tag/index.blade.php ENDPATH**/ ?>