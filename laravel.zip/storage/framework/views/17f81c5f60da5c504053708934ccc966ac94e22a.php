<?php $__env->startSection('titulo_card', 'Solicita tu Tag Online!'); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="form-group text-center">
        <h5><p class="small text-primary">Seleccione el Tipo de Solicitud a Realizar :</p></h5>
    </div>  

    <form class="user" action="<?php echo e(view('tag.natural')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="submit" value="Persona Natural" class="btn btn-primary btn-user btn-block" />
        </div>
    </form>

    <form class="user" action="<?php echo e(view('tag.empresa')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <input type="submit" value="Empresa" class="btn btn-facebook btn-user btn-block" />
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE/resources/views/tag/iindex.blade.php ENDPATH**/ ?>