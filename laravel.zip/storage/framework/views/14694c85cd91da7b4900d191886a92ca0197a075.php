<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <?php echo $__env->yieldContent('titulo'); ?>
        </h1>
    </div>

    <!-- Content Row -->
    <div class="row">

        <div class="col sm-12">
            <?php echo $__env->yieldContent('contenido'); ?>
        </div>

    </div>

</div><?php /**PATH /Volumes/Online/Desarrollos/AdminLTE/resources/views/layouts/partials/content.blade.php ENDPATH**/ ?>